package Package;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName = "Disconnessione")
public class Disconnessione 
{
	@WebMethod(operationName = "Esci")
    public boolean Esci(@WebParam(name = "Username") String Username, @WebParam(name = "Accesso")  boolean Accesso) 
	{
        if (Accesso == true)
        {
            Accesso = false;
        }
        return Accesso;
    }
}
